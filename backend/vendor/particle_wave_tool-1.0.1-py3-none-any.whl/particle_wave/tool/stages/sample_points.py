"""
sample_points.py
────────────────
Stage 3: gradient-weighted Poisson disk sampling.

Implements the Bridson (2007) fast Poisson disk sampling algorithm with a
variable exclusion radius driven by the local edge magnitude.  High-magnitude
pixels → small radius → dense cluster of samples; low-magnitude pixels → large
radius → sparse samples.  An optional background-fill pass places sparse
samples over non-edge regions.

r(x, y) = r_max - (r_max - r_min) · M(x, y)^γ

Reference: Bridson, R.  Fast Poisson Disk Sampling in Arbitrary Dimensions.
SIGGRAPH Sketches 2007.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass

import numpy as np

from .extract_edges import EdgeMap

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Result dataclass
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class SampledPoints:
    """Output of the point-sampling stage."""
    x: np.ndarray        # float32 (N,) ∈ [0, 1]  — normalised column
    y: np.ndarray        # float32 (N,) ∈ [0, 1]  — normalised row
    weight: np.ndarray   # float32 (N,) ∈ [0, 1]  — edge magnitude at sample
    group: np.ndarray    # int32   (N,)            — semantic group (0 = default)
    N: int               # total sample count


# ──────────────────────────────────────────────────────────────────────────────
# Config
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class SamplingConfig:
    target_points: int = 4000
    """Desired total number of output points (edge + background combined)."""

    feature_mode: str = "hybrid"
    """Feature importance mode: 'edge' | 'tone' | 'hybrid' | 'bw_intensity'."""

    bw_polarity: str = "white_more"
    """BW mode density direction: 'white_more' or 'black_more'."""

    bw_gamma: float = 1.0
    """Gamma curve for BW intensity importance map."""

    bw_blur_sigma: float = 0.0
    """Optional blur sigma on grayscale before BW-intensity mapping."""

    edge_weight: float = 0.8
    """Weight applied to edge magnitude when `feature_mode='hybrid'`."""

    tone_weight: float = 0.65
    """Weight applied to tone/local-contrast saliency when `feature_mode='hybrid'`."""

    tone_sigma: float = 10.0
    """Gaussian blur sigma used to compute local-contrast tone saliency."""

    tone_gamma: float = 0.85
    """Gamma curve for tone saliency; <1 increases mid-tone feature presence."""

    feature_quantile: float = 0.62
    """Quantile threshold for converting importance map into the seed mask."""

    feature_floor: float = 0.08
    """Minimum threshold for keeping features in the sampling seed mask."""

    min_radius: float = 2.0
    """Minimum inter-point distance in pixels (at maximum edge magnitude)."""

    max_radius: float = 12.0
    """Maximum inter-point distance in pixels (at zero edge magnitude)."""

    radius_gamma: float = 0.5
    """Exponent controlling the density-to-magnitude curve. <1 → denser edges."""

    k_candidates: int = 30
    """Bridson's k — number of trial candidates per active point."""

    fill_background: bool = False
    """If True, add a sparse secondary pass over non-edge regions."""

    background_ratio: float = 0.15
    """Background points as a fraction of the edge sample count."""

    rng_seed: int | None = None
    """Random seed for reproducibility. None = non-deterministic."""


# ──────────────────────────────────────────────────────────────────────────────
# Sampler
# ──────────────────────────────────────────────────────────────────────────────

class PointSampler:
    def __init__(self, config: SamplingConfig | None = None) -> None:
        self.cfg = config or SamplingConfig()
        self._rng = np.random.default_rng(self.cfg.rng_seed)

    # ── Public ────────────────────────────────────────────────────────────────

    def sample(self, edge_map: EdgeMap) -> SampledPoints:
        """
        Parameters
        ----------
        edge_map : EdgeMap  — binary mask + magnitude (H, W)

        Returns
        -------
        SampledPoints
        """
        height, width = edge_map.binary.shape
        mag = edge_map.magnitude  # float32 (H, W) ∈ [0, 1]

        # Build the variable-radius map in pixels
        radius_map = self._compute_radius_map(mag)

        # Primary pass: sample from edge (or near-edge) pixels
        candidates_px = self._edge_seeds(edge_map.binary, self.cfg.target_points)
        points_px = self._poisson_disk(candidates_px, radius_map, height, width)

        xs, ys, ws = [], [], []
        for (r, c) in points_px:
            xs.append(c / width)
            ys.append(r / height)
            ws.append(float(mag[r, c]))

        groups = [0] * len(xs)

        # Optional background fill
        if self.cfg.fill_background and len(xs) > 0:
            bg_target = max(1, int(len(xs) * self.cfg.background_ratio))
            bg_mask = ~edge_map.binary
            bg_seeds = self._edge_seeds(bg_mask, bg_target * 4, weight_map=None)
            bg_pts = self._poisson_disk(
                bg_seeds,
                radius_map * 2.0,
                height,
                width,
                max_points=bg_target,
            )
            for (r, c) in bg_pts:
                xs.append(c / width)
                ys.append(r / height)
                ws.append(float(mag[r, c]) * 0.3)  # dim background points
                groups.append(0)

        point_count = len(xs)
        log.info("Sampled %d points from image (%dx%d)", point_count, width, height)

        return SampledPoints(
            x=np.array(xs, dtype=np.float32),
            y=np.array(ys, dtype=np.float32),
            weight=np.array(ws, dtype=np.float32),
            group=np.array(groups, dtype=np.int32),
            N=point_count,
        )

    # ── Private ───────────────────────────────────────────────────────────────

    def _compute_radius_map(self, mag: np.ndarray) -> np.ndarray:
        """Vectorised variable-radius map. r ∈ [r_min, r_max]."""
        cfg = self.cfg
        influence = np.power(mag.clip(0, 1), cfg.radius_gamma)
        r_map = cfg.max_radius - (cfg.max_radius - cfg.min_radius) * influence
        return r_map.astype(np.float32)

    def _edge_seeds(
        self,
        mask: np.ndarray,
        n_seeds: int,
        weight_map: np.ndarray | None = None,
    ) -> list[tuple[int, int]]:
        """
        Return up to `n_seeds` (row, col) integer pixel positions from `mask` pixels.
        If weight_map is provided, sampling is proportional to weights.
        """
        rows, cols = np.where(mask)
        if len(rows) == 0:
            # fallback: sample from the entire image
            height, width = mask.shape
            rows = np.arange(height).repeat(width)
            cols = np.tile(np.arange(width), height)

        n = min(n_seeds, len(rows))
        if weight_map is not None:
            w = weight_map[rows, cols].astype(np.float64)
            w = w / (w.sum() + 1e-12)
        else:
            w = None

        idx = self._rng.choice(len(rows), size=n, replace=False, p=w)
        return list(zip(rows[idx].tolist(), cols[idx].tolist()))

    def _poisson_disk(
        self,
        seeds: list[tuple[int, int]],
        radius_map: np.ndarray,
        height: int,
        width: int,
        max_points: int | None = None,
    ) -> list[tuple[int, int]]:
        """
        Bridson fast Poisson disk sampling with variable radius.

        Parameters
        ----------
        seeds      : initial active points (row, col) int
        radius_map : float32 (H, W) — per-pixel minimum exclusion radius
        height, width : image dimensions
        max_points : stop when this many samples are collected

        Returns
        -------
        list of (row, col) accepted sample coordinates
        """
        if max_points is None:
            max_points = self.cfg.target_points

        r_min = self.cfg.min_radius

        # ── Why the acceleration grid is coarse ───────────────────────────
        #
        # Bridson sizes the grid at r/sqrt(2) so that each cell holds at most
        # one sample, which is right when r is a constant. Here the radius
        # varies per pixel across [min_radius, max_radius], and the exclusion
        # test uses the radius at the *candidate* — which in a low-detail
        # region is max_radius, six times min_radius at the defaults.
        #
        # A grid sized for min_radius therefore forces a window of
        # (2 * max_radius / (min_radius / sqrt(2)))^2 cells — around 290 at the
        # defaults — nearly all of them empty, walked one at a time in Python.
        # That single detail, not the sampling itself, was the dominant cost of
        # the whole pipeline: profiling a 700px image put 7.4 s of a 7.5 s run
        # inside this function.
        #
        # Sizing cells by max_radius instead bounds the window at 3x3 for any
        # candidate, so the work per test is proportional to the points that
        # could plausibly conflict rather than to the area being searched.
        # Cells hold a list rather than a single index.
        #
        # The fine grid is kept alongside, because its one-slot-per-cell
        # behaviour is load-bearing rather than incidental. A candidate is
        # *tested* at fractional coordinates but *stored* truncated to whole
        # pixels, so an accepted sample can end up marginally closer to its
        # neighbour than the radius that admitted it — close enough to share a
        # fine cell. When that happened the later sample overwrote the earlier
        # one in the grid and the earlier one stopped being visible to the
        # exclusion test, while remaining in the output. Dropping the fine grid
        # silently changed which points were admitted from then on; three of
        # twenty equivalence cases diverged before this was put back.
        cell_size = max(self.cfg.max_radius, r_min)
        grid_h = int(height // cell_size) + 1
        grid_w = int(width // cell_size) + 1

        # Flat list-of-lists: one Python list per cell, holding sample indices.
        cells: list[list[int]] = [[] for _ in range(grid_h * grid_w)]

        fine_size = r_min / math.sqrt(2)
        fine_h = int(math.ceil(height / fine_size))
        fine_w = int(math.ceil(width / fine_size))
        fine_grid = np.full((fine_h, fine_w), -1, dtype=np.int32)

        accepted: list[tuple[int, int]] = []
        active: list[int] = []           # indices into `accepted`

        # Coordinates as plain floats. The neighbour test compares a few values
        # at a time, where Python arithmetic beats the per-call overhead of
        # dropping into numpy.
        acc_r: list[float] = []
        acc_c: list[float] = []

        def accept(r: int, c: int) -> None:
            idx = len(accepted)
            accepted.append((r, c))
            active.append(idx)
            acc_r.append(float(r))
            acc_c.append(float(c))

            # Mirror the fine grid's overwrite: whatever occupied this cell
            # stops being visible to the exclusion test, exactly as it did when
            # the grid held a single index per cell.
            fr = int(r / fine_size)
            fc = int(c / fine_size)
            if 0 <= fr < fine_h and 0 <= fc < fine_w:
                displaced = int(fine_grid[fr, fc])
                if displaced >= 0:
                    hidden = cells[
                        int(accepted[displaced][0] / cell_size) * grid_w
                        + int(accepted[displaced][1] / cell_size)
                    ]
                    if displaced in hidden:
                        hidden.remove(displaced)
                fine_grid[fr, fc] = idx

            cells[int(r / cell_size) * grid_w + int(c / cell_size)].append(idx)

        def conflicts(r: float, c: float, excl_r: float) -> bool:
            """True if (r, c) is closer than the local radius to any sample."""
            gr0 = max(0, int((r - excl_r) / cell_size))
            gr1 = min(grid_h - 1, int((r + excl_r) / cell_size))
            gc0 = max(0, int((c - excl_r) / cell_size))
            gc1 = min(grid_w - 1, int((c + excl_r) / cell_size))

            # The exclusion radius is read at the candidate and so does not
            # vary across the window. Deferred until a neighbour actually turns
            # up, because in sparse regions the window is usually empty and the
            # lookup would be the only work done.
            threshold = None

            for gr in range(gr0, gr1 + 1):
                row = gr * grid_w
                for gc in range(gc0, gc1 + 1):
                    for pidx in cells[row + gc]:
                        if threshold is None:
                            ri = radius_map[
                                int(min(max(r, 0.0), height - 1)),
                                int(min(max(c, 0.0), width - 1)),
                            ]
                            threshold = ri * ri
                        dr = r - acc_r[pidx]
                        dc = c - acc_c[pidx]
                        if dr * dr + dc * dc < threshold:
                            return True
            return False

        # Seed the active list
        for (sr, sc) in seeds:
            if not conflicts(sr, sc, radius_map[sr, sc]):
                accept(sr, sc)
                if len(accepted) >= max_points:
                    break

        k = self.cfg.k_candidates
        two_pi = 2 * math.pi

        while active and len(accepted) < max_points:
            # Pick a random active point
            active_choice = self._rng.integers(0, len(active))
            base_idx = active[active_choice]
            br, bc = accepted[base_idx]
            base_r = radius_map[br, bc]
            found = False

            for _ in range(k):
                # Random point in the annulus [base_r, 2*base_r] around the
                # base sample.
                #
                # Drawn one scalar at a time on purpose. Batching the k pairs
                # up front would be faster, but this loop breaks early on the
                # first success and would leave the surplus draws consumed,
                # shifting every subsequent decision. Reproducibility under a
                # fixed `rng_seed` is worth more than the microseconds.
                angle = self._rng.random() * two_pi
                dist  = base_r + self._rng.random() * base_r
                nr = br + dist * math.sin(angle)
                nc = bc + dist * math.cos(angle)

                ir = int(min(max(nr, 0.0), height - 1))
                ic = int(min(max(nc, 0.0), width - 1))
                excl_r = radius_map[ir, ic]

                if 0 <= nr < height and 0 <= nc < width and not conflicts(nr, nc, excl_r):
                    accept(ir, ic)
                    found = True
                    if len(accepted) >= max_points:
                        break

            if not found:
                # Remove from active list (swap with last)
                active[active_choice] = active[-1]
                active.pop()

        return accepted
