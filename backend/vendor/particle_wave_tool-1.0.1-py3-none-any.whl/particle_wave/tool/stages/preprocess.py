"""
preprocess.py
─────────────
Stage 1: normalise an input image into a float32 grayscale array ready for
feature extraction. Supports any image format that Pillow can decode.

Pipeline steps:
    1. Decode to RGB
    2. Resize (Lanczos, longest-edge cap)
    3. Convert to grayscale (BT.601 luminance)
    4. Optional CLAHE contrast enhancement
    5. Normalise to [0, 1]
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
from PIL import Image

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Result dataclass
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class PreprocessResult:
    """Output of the preprocessing stage."""
    image: np.ndarray           # float32, shape (H, W), values ∈ [0, 1]
    original_size: tuple[int, int]   # (W, H) before any resize
    processed_size: tuple[int, int]  # (W, H) after resize


# ──────────────────────────────────────────────────────────────────────────────
# Config
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class PreprocessConfig:
    max_resolution: int = 1024
    """Longest edge is capped to this value (pixels)."""

    clahe_clip: float = 2.0
    """CLAHE clip limit. Set to 0 to disable CLAHE."""

    clahe_tile_grid: tuple[int, int] = field(default_factory=lambda: (8, 8))
    """Tile grid size for CLAHE."""

    blur_sigma: float = 0.0
    """Optional pre-blur sigma (Gaussian). 0 = disabled."""


# ──────────────────────────────────────────────────────────────────────────────
# Processor
# ──────────────────────────────────────────────────────────────────────────────

class Preprocessor:
    def __init__(self, config: PreprocessConfig | None = None) -> None:
        self.cfg = config or PreprocessConfig()

    # ── Public ────────────────────────────────────────────────────────────────

    def process(self, source: str | Path | np.ndarray | Image.Image) -> PreprocessResult:
        """
        Run the full preprocessing pipeline.

        Parameters
        ----------
        source : path, ndarray (H,W,3/4 uint8) or PIL Image

        Returns
        -------
        PreprocessResult
        """
        pil = self._load(source)
        original_size = pil.size  # (W, H)

        pil = self._resize(pil)
        processed_size = pil.size

        gray = self._to_grayscale(pil)

        if self.cfg.clahe_clip > 0:
            gray = self._apply_clahe(gray)

        if self.cfg.blur_sigma > 0:
            gray = self._apply_blur(gray)

        image = gray.astype(np.float32)

        # Normalise to [0, 1]
        lo, hi = image.min(), image.max()
        if hi > lo:
            image = (image - lo) / (hi - lo)
        else:
            image = np.zeros_like(image)

        log.debug(
            "Preprocessed: %s → %s  (clahe=%.1f, blur=%.1f)",
            original_size, processed_size, self.cfg.clahe_clip, self.cfg.blur_sigma,
        )
        return PreprocessResult(
            image=image,
            original_size=original_size,
            processed_size=processed_size,
        )

    # ── Private steps ─────────────────────────────────────────────────────────

    @staticmethod
    def _load(source: str | Path | np.ndarray | Image.Image) -> Image.Image:
        if isinstance(source, (str, Path)):
            return Image.open(source).convert("RGB")
        if isinstance(source, np.ndarray):
            if source.dtype != np.uint8:
                source = (source * 255).clip(0, 255).astype(np.uint8)
            mode = "RGB" if source.ndim == 3 and source.shape[2] == 3 else "RGBA"
            return Image.fromarray(source, mode).convert("RGB")
        if isinstance(source, Image.Image):
            return source.convert("RGB")
        raise TypeError(f"Unsupported source type: {type(source)}")

    def _resize(self, pil: Image.Image) -> Image.Image:
        width, height = pil.size
        longest = max(width, height)
        if longest <= self.cfg.max_resolution:
            return pil
        scale = self.cfg.max_resolution / longest
        new_width = max(1, round(width * scale))
        new_height = max(1, round(height * scale))
        return pil.resize((new_width, new_height), Image.LANCZOS)

    @staticmethod
    def _to_grayscale(pil: Image.Image) -> np.ndarray:
        """BT.601 luminance: L = 0.299R + 0.587G + 0.114B. Returns uint8 (H,W)."""
        arr = np.asarray(pil, dtype=np.float32)
        gray = 0.299 * arr[:, :, 0] + 0.587 * arr[:, :, 1] + 0.114 * arr[:, :, 2]
        return gray.astype(np.uint8)

    def _apply_clahe(self, gray_u8: np.ndarray) -> np.ndarray:
        try:
            import cv2  # optional dependency
            clahe = cv2.createCLAHE(
                clipLimit=self.cfg.clahe_clip,
                tileGridSize=self.cfg.clahe_tile_grid,
            )
            return clahe.apply(gray_u8)
        except ImportError:
            # Fallback: simple global histogram equalization via Pillow
            log.warning("cv2 not available; falling back to Pillow ImageOps.equalize for contrast.")
            from PIL import ImageOps
            pil_gray = Image.fromarray(gray_u8)
            return np.asarray(ImageOps.equalize(pil_gray), dtype=np.uint8)

    def _apply_blur(self, gray_u8: np.ndarray) -> np.ndarray:
        from scipy.ndimage import gaussian_filter  # type: ignore[import-not-found]

        blurred = gaussian_filter(gray_u8.astype(np.float32), sigma=self.cfg.blur_sigma)
        return blurred.astype(np.uint8)
