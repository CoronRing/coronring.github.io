"""
extract_ml.py
─────────────
Optional ML-based edge/saliency extraction stage using ONNX Runtime.

Supported models:
    - DexiNed  (Dense Extreme Inception Network for Edge Detection)
    - HED      (Holistically-nested Edge Detection, RIFE-converted)

The module gracefully falls back to the classic Canny extractor if:
    - onnxruntime is not installed
    - The ONNX model file cannot be found

Model output: a probability map ∈ [0, 1] that is thresholded to produce
the binary edge mask. The probability values are used directly as the
magnitude map for density-weighted sampling.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .extract_edges import CannyExtractor, EdgeMap

log = logging.getLogger(__name__)

# ImageNet normalisation parameters
_IMAGENET_MEAN = np.array([0.485, 0.456, 0.406], dtype=np.float32)
_IMAGENET_STD  = np.array([0.229, 0.224, 0.225], dtype=np.float32)


# ──────────────────────────────────────────────────────────────────────────────
# Config
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class MLExtractorConfig:
    model_name: str = "dexined"
    """Which model to load. 'dexined' | 'hed'"""

    model_path: str | None = None
    """
    Absolute path to the .onnx file.
    If None, the tool looks for the model in the standard model cache:
        tool/models/<model_name>.onnx
    """

    threshold: float = 0.4
    """Edge probability threshold for binary mask."""

    execution_provider: str = "CPUExecutionProvider"
    """ONNX execution provider. Change to 'CUDAExecutionProvider' for GPU."""

    input_size: tuple[int, int] | None = None
    """
    (H, W) to resize input to before inference.
    None = use model's native input (or image size if dynamic).
    """

    fallback_to_classic: bool = True
    """If True, fall back to Canny when model/runtime is unavailable."""


# ──────────────────────────────────────────────────────────────────────────────
# Extractor
# ──────────────────────────────────────────────────────────────────────────────

class MLExtractor:
    """
    ML-based edge extractor backed by ONNX Runtime.
    The model path is resolved lazily on first use.
    """

    # Default model filenames (searched inside tool/models/)
    _MODEL_FILES = {
        "dexined": "dexined.onnx",
        "hed":     "hed.onnx",
    }

    def __init__(self, config: MLExtractorConfig | None = None) -> None:
        self.cfg = config or MLExtractorConfig()
        self._session = None   # lazy-loaded

    def extract(self, image: np.ndarray) -> EdgeMap:
        """
        Parameters
        ----------
        image : float32 (H, W) ∈ [0, 1]  — preprocessed grayscale image

        Returns
        -------
        EdgeMap
        """
        try:
            session = self._get_session()
        except RuntimeError as exc:
            if self.cfg.fallback_to_classic:
                log.warning("ML extractor unavailable (%s); falling back to Canny.", exc)
                return CannyExtractor().extract(image)
            raise

        prob_map = self._run_inference(session, image)

        # Threshold to binary
        binary = prob_map >= self.cfg.threshold

        log.debug(
            "ML (%s): %d edge pixels (%.1f%%)",
            self.cfg.model_name, binary.sum(), binary.mean() * 100,
        )
        return EdgeMap(binary=binary, magnitude=prob_map)

    # ── Private ───────────────────────────────────────────────────────────────

    def _get_session(self):
        if self._session is not None:
            return self._session

        try:
            import onnxruntime as ort  # type: ignore[import-not-found]
        except ImportError as exc:
            raise RuntimeError("onnxruntime not installed. `pip install onnxruntime`") from exc

        model_path = self._resolve_model_path()
        log.info("Loading ONNX model: %s", model_path)

        sess_opts = ort.SessionOptions()
        sess_opts.log_severity_level = 3  # suppress verbose ONNX logs
        self._session = ort.InferenceSession(
            str(model_path),
            sess_options=sess_opts,
            providers=[self.cfg.execution_provider],
        )
        return self._session

    def _resolve_model_path(self) -> Path:
        if self.cfg.model_path:
            p = Path(self.cfg.model_path)
            if not p.exists():
                raise RuntimeError(f"ONNX model not found at: {p}")
            return p

        # Search relative to this file's parent package
        filename = self._MODEL_FILES.get(self.cfg.model_name)
        if filename is None:
            raise RuntimeError(
                f"Unknown model '{self.cfg.model_name}'. "
                f"Valid options: {list(self._MODEL_FILES)}"
            )
        candidate = Path(__file__).parent.parent / "models" / filename
        if not candidate.exists():
            raise RuntimeError(
                f"ONNX model '{filename}' not found at {candidate}. "
                "Download it with: particle-wave download-model "
                f"--model {self.cfg.model_name}"
            )
        return candidate

    def _run_inference(self, session, image: np.ndarray) -> np.ndarray:
        """Prepare input tensor, run inference, return (H, W) probability map."""
        height, width = image.shape

        # Convert grayscale → RGB (models expect 3-channel)
        rgb = np.stack([image, image, image], axis=-1)  # (H, W, 3) float32 ∈ [0,1]

        # Resize if requested
        if self.cfg.input_size is not None:
            from PIL import Image as PILImage
            target_h, target_w = self.cfg.input_size
            pil = PILImage.fromarray((rgb * 255).astype(np.uint8), "RGB")
            pil = pil.resize((target_w, target_h), PILImage.BILINEAR)
            rgb = np.asarray(pil, dtype=np.float32) / 255.0

        # ImageNet normalisation
        tensor = (rgb - _IMAGENET_MEAN) / _IMAGENET_STD
        tensor = tensor.transpose(2, 0, 1)[np.newaxis]

        # Infer — get the first output node
        input_name  = session.get_inputs()[0].name
        output_name = session.get_outputs()[0].name
        outputs = session.run([output_name], {input_name: tensor})
        prob = outputs[0]  # varying shapes depending on model

        # Squeeze to (H_out, W_out)
        prob = np.squeeze(prob).astype(np.float32)

        # Sigmoid activation if values are outside [0,1]
        if prob.min() < 0 or prob.max() > 1:
            prob = 1.0 / (1.0 + np.exp(-prob))

        # Resize back to original image dimensions if needed
        if prob.shape != (height, width):
            from PIL import Image as PILImage

            pil = PILImage.fromarray((prob * 255).clip(0, 255).astype(np.uint8))
            pil = pil.resize((width, height), PILImage.BILINEAR)
            prob = np.asarray(pil, dtype=np.float32) / 255.0

        # Normalise to [0, 1]
        lo, hi = prob.min(), prob.max()
        if hi > lo:
            prob = (prob - lo) / (hi - lo)

        return prob
