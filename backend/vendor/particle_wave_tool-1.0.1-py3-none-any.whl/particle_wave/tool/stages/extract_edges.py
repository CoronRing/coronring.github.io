"""
extract_edges.py
────────────────
Classic CV edge-extraction stage (Canny) with gradient magnitude retention.

Pipeline steps:
    1. Gaussian pre-blur
    2. Sobel gradient (magnitude + angle)
    3. Non-maximum suppression
    4. Hysteresis thresholding

The magnitude field is retained for density-weighted sampling in sample_points.py.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

import numpy as np
from scipy.ndimage import gaussian_filter, sobel  # type: ignore[import-not-found]

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Result dataclass
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class EdgeMap:
    """Result of feature extraction."""
    binary: np.ndarray       # bool (H, W) — thinned edge mask
    magnitude: np.ndarray    # float32 (H, W) ∈ [0, 1] — gradient magnitude


# ──────────────────────────────────────────────────────────────────────────────
# Config
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class CannyConfig:
    blur_sigma: float = 1.4
    """Pre-blur sigma before gradient computation."""

    low_thresh: float = 0.05
    """Hysteresis low threshold ∈ [0, 1]."""

    high_thresh: float = 0.15
    """Hysteresis high threshold ∈ [0, 1]."""


# ──────────────────────────────────────────────────────────────────────────────
# Extractor
# ──────────────────────────────────────────────────────────────────────────────

class CannyExtractor:
    """
    Canny edge detector implemented with scipy for portability.
    For production use, prefer cv2.Canny (faster); this implementation
    is the pure-Python fallback.
    """

    def __init__(self, config: CannyConfig | None = None) -> None:
        self.cfg = config or CannyConfig()

    def extract(self, image: np.ndarray) -> EdgeMap:
        """
        Parameters
        ----------
        image : float32 (H, W) ∈ [0, 1]

        Returns
        -------
        EdgeMap
        """
        # Try fast cv2 path first
        try:
            return self._extract_cv2(image)
        except ImportError:
            return self._extract_scipy(image)

    # ── cv2 fast path ─────────────────────────────────────────────────────────

    def _extract_cv2(self, image: np.ndarray) -> EdgeMap:
        import cv2
        u8 = (image * 255).clip(0, 255).astype(np.uint8)

        # cv2 Canny does its own internal Gaussian blur; we honour our sigma
        # by blurring first when sigma > 0.
        if self.cfg.blur_sigma > 0:
            ksize = int(self.cfg.blur_sigma * 6) | 1  # odd kernel
            ksize = max(ksize, 3)
            blurred = cv2.GaussianBlur(u8, (ksize, ksize), self.cfg.blur_sigma)
        else:
            blurred = u8

        low  = int(self.cfg.low_thresh  * 255)
        high = int(self.cfg.high_thresh * 255)
        edges_u8 = cv2.Canny(blurred, low, high)
        binary = edges_u8 > 0

        # Gradient magnitude for density weighting (Sobel)
        gy = cv2.Sobel(blurred, cv2.CV_32F, 0, 1, ksize=3)
        gx = cv2.Sobel(blurred, cv2.CV_32F, 1, 0, ksize=3)
        mag = np.hypot(gx, gy).astype(np.float32)
        if mag.max() > 0:
            mag /= mag.max()

        log.debug("Canny (cv2): %d edge pixels (%.1f%%)", binary.sum(), binary.mean() * 100)
        return EdgeMap(binary=binary, magnitude=mag)

    # ── scipy pure-Python path ────────────────────────────────────────────────

    def _extract_scipy(self, image: np.ndarray) -> EdgeMap:
        log.warning("cv2 not available; using scipy Canny (slower)")

        if self.cfg.blur_sigma > 0:
            blurred = gaussian_filter(image, sigma=self.cfg.blur_sigma)
        else:
            blurred = image.copy()

        # Sobel gradients
        gx = sobel(blurred, axis=1)
        gy = sobel(blurred, axis=0)
        mag = np.hypot(gx, gy).astype(np.float32)
        angle = np.arctan2(gy, gx)

        # Normalise magnitude for thresholding
        max_mag = mag.max()
        if max_mag == 0:
            return EdgeMap(binary=np.zeros_like(image, dtype=bool), magnitude=mag)
        mag_norm = mag / max_mag

        # Non-maximum suppression
        nms = self._nms(mag_norm, angle)

        # Hysteresis thresholding
        strong = nms >= self.cfg.high_thresh
        weak   = (nms >= self.cfg.low_thresh) & ~strong
        binary = self._hysteresis(strong, weak)

        log.debug("Canny (scipy): %d edge pixels (%.1f%%)", binary.sum(), binary.mean() * 100)
        return EdgeMap(binary=binary, magnitude=mag_norm)

    @staticmethod
    def _nms(mag: np.ndarray, angle: np.ndarray) -> np.ndarray:
        """Non-maximum suppression: thin edges to 1-pixel width."""
        height, width = mag.shape
        out = np.zeros_like(mag)
        # Quantise angle to 4 directions (0°, 45°, 90°, 135°)
        angle_deg = np.degrees(angle) % 180

        for i in range(1, height - 1):
            for j in range(1, width - 1):
                a = angle_deg[i, j]
                m = mag[i, j]
                if a < 22.5 or a >= 157.5:
                    n1, n2 = mag[i, j - 1], mag[i, j + 1]
                elif a < 67.5:
                    n1, n2 = mag[i - 1, j + 1], mag[i + 1, j - 1]
                elif a < 112.5:
                    n1, n2 = mag[i - 1, j], mag[i + 1, j]
                else:
                    n1, n2 = mag[i - 1, j - 1], mag[i + 1, j + 1]
                if m >= n1 and m >= n2:
                    out[i, j] = m
        return out

    @staticmethod
    def _hysteresis(strong: np.ndarray, weak: np.ndarray) -> np.ndarray:
        """Keep weak edges only when connected (8-neighbour) to a strong edge."""
        from scipy.ndimage import label  # type: ignore[import-not-found]

        combined = strong | weak
        labeled, _ = label(combined)
        # Keep only labeled regions that contain at least one strong pixel
        strong_labels = np.unique(labeled[strong])
        strong_labels = strong_labels[strong_labels != 0]
        binary = np.isin(labeled, strong_labels)
        return binary
