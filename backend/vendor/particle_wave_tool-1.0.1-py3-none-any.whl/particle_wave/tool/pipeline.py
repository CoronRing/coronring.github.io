"""
pipeline.py
───────────
Orchestrates the full image → .pwcloud conversion pipeline.

Stages:
    1. Preprocess  (preprocess.py)
    2. Feature extraction  (extract_edges.py or extract_ml.py)
    3. Point sampling  (sample_points.py)
    4. Export  (exporters/pwcloud.py)

Custom extractors can be registered at runtime via `Pipeline.register_extractor`.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image

from .exporters.pwcloud import ExportConfig, PwcloudExporter  # type: ignore
from .stages.extract_edges import CannyConfig, CannyExtractor, EdgeMap
from .stages.extract_ml import MLExtractor, MLExtractorConfig
from .stages.preprocess import PreprocessConfig, Preprocessor
from .stages.sample_points import PointSampler, SamplingConfig  # type: ignore

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Extractor registry (extension point §14.1)
# ---------------------------------------------------------------------------

_EXTRACTOR_REGISTRY: dict[str, Callable[..., Any]] = {}


def register_extractor(name: str, factory: Callable[..., Any]) -> None:
    """
    Register a custom extractor factory under `name`.

    The factory is called with the extractor sub-config dict as keyword
    arguments and must return an object implementing `extract(image) -> EdgeMap`.
    """
    _EXTRACTOR_REGISTRY[name] = factory
    log.debug("Registered extractor: %s", name)


# ---------------------------------------------------------------------------
# Pipeline config
# ---------------------------------------------------------------------------

@dataclass
class PipelineConfig:
    preprocess: PreprocessConfig = field(default_factory=PreprocessConfig)
    extractor: str = "classic"
    extractor_classic: CannyConfig = field(default_factory=CannyConfig)
    extractor_ml: MLExtractorConfig = field(default_factory=MLExtractorConfig)
    sampling: SamplingConfig = field(default_factory=SamplingConfig)
    output: ExportConfig = field(default_factory=ExportConfig)

    @classmethod
    def from_dict(cls, d: dict) -> PipelineConfig:
        """Construct from a nested dict (e.g. loaded from YAML)."""
        cfg = cls()
        if "preprocessing" in d:
            p = d["preprocessing"]
            cfg.preprocess.max_resolution = p.get("max_resolution", cfg.preprocess.max_resolution)
            cfg.preprocess.clahe_clip     = p.get("clahe_clip",     cfg.preprocess.clahe_clip)
            tile = p.get("clahe_tile_grid")
            if tile:
                cfg.preprocess.clahe_tile_grid = tuple(tile)
            cfg.preprocess.blur_sigma     = p.get("blur_sigma",     cfg.preprocess.blur_sigma)

        cfg.extractor = d.get("extractor", cfg.extractor)

        if "extractor_classic" in d:
            ec = d["extractor_classic"]
            cfg.extractor_classic.blur_sigma = ec.get(
                "blur_sigma", cfg.extractor_classic.blur_sigma
            )
            cfg.extractor_classic.low_thresh = ec.get(
                "low_thresh", cfg.extractor_classic.low_thresh
            )
            cfg.extractor_classic.high_thresh = ec.get(
                "high_thresh", cfg.extractor_classic.high_thresh
            )

        if "extractor_ml" in d:
            em = d["extractor_ml"]
            cfg.extractor_ml.model_name = em.get(
                "model_name", cfg.extractor_ml.model_name
            )
            cfg.extractor_ml.model_path = em.get(
                "model_path", cfg.extractor_ml.model_path
            )
            cfg.extractor_ml.threshold = em.get(
                "threshold", cfg.extractor_ml.threshold
            )
            cfg.extractor_ml.execution_provider = em.get(
                "execution_provider", cfg.extractor_ml.execution_provider
            )
            cfg.extractor_ml.fallback_to_classic = em.get(
                "fallback_to_classic", cfg.extractor_ml.fallback_to_classic
            )
            sz = em.get("input_size")
            if sz:
                cfg.extractor_ml.input_size = tuple(sz)

        if "sampling" in d:
            s = d["sampling"]
            cfg.sampling.feature_mode     = s.get("feature_mode",     cfg.sampling.feature_mode)
            cfg.sampling.bw_polarity      = s.get("bw_polarity",      cfg.sampling.bw_polarity)
            cfg.sampling.bw_gamma         = s.get("bw_gamma",         cfg.sampling.bw_gamma)
            cfg.sampling.bw_blur_sigma    = s.get("bw_blur_sigma",    cfg.sampling.bw_blur_sigma)
            cfg.sampling.edge_weight      = s.get("edge_weight",      cfg.sampling.edge_weight)
            cfg.sampling.tone_weight      = s.get("tone_weight",      cfg.sampling.tone_weight)
            cfg.sampling.tone_sigma       = s.get("tone_sigma",       cfg.sampling.tone_sigma)
            cfg.sampling.tone_gamma       = s.get("tone_gamma",       cfg.sampling.tone_gamma)
            cfg.sampling.feature_quantile = s.get("feature_quantile", cfg.sampling.feature_quantile)
            cfg.sampling.feature_floor    = s.get("feature_floor",    cfg.sampling.feature_floor)
            cfg.sampling.target_points    = s.get("target_points",    cfg.sampling.target_points)
            cfg.sampling.min_radius       = s.get("min_radius",       cfg.sampling.min_radius)
            cfg.sampling.max_radius       = s.get("max_radius",       cfg.sampling.max_radius)
            cfg.sampling.radius_gamma     = s.get("radius_gamma",     cfg.sampling.radius_gamma)
            cfg.sampling.k_candidates     = s.get("k_candidates",     cfg.sampling.k_candidates)
            cfg.sampling.fill_background  = s.get("fill_background",  cfg.sampling.fill_background)
            cfg.sampling.background_ratio = s.get("background_ratio", cfg.sampling.background_ratio)
            cfg.sampling.rng_seed         = s.get("rng_seed",         cfg.sampling.rng_seed)

        if "output" in d:
            o = d["output"]
            cfg.output.encoding        = o.get("encoding",        cfg.output.encoding)
            cfg.output.pretty          = o.get("pretty",          cfg.output.pretty)
            cfg.output.float_precision = o.get("float_precision", cfg.output.float_precision)

        return cfg

    @classmethod
    def from_yaml(cls, path: str | Path) -> PipelineConfig:
        """Load configuration from a YAML file."""
        import yaml

        with open(path, encoding="utf-8") as fh:
            d = yaml.safe_load(fh)
        return cls.from_dict(d or {})

    @classmethod
    def from_defaults(cls) -> PipelineConfig:
        """Load the bundled defaults.yaml."""
        defaults_path = Path(__file__).parent / "config" / "defaults.yaml"
        return cls.from_yaml(defaults_path)


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------

class Pipeline:
    def __init__(self, config: PipelineConfig | None = None) -> None:
        self.cfg = config or PipelineConfig.from_defaults()

    # ── Public ────────────────────────────────────────────────────────────────

    def build(
        self,
        source: str | Path | np.ndarray | Image.Image,
        *,
        source_name: str | None = None,
    ) -> dict:
        """
        Run the full pipeline and return the .pwcloud document in memory.

        This is the disk-free half of `run`. It exists so callers that never
        want a file — a web service handling an upload, a notebook, a test —
        do not have to invent a temporary path and read it back. A server in
        particular should not be writing user-supplied images to its own
        filesystem just to convert them.

        Parameters
        ----------
        source      : input image (path, ndarray, or PIL Image)
        source_name : name recorded in the output metadata. Defaults to the
                      file name when `source` is a path, else "unknown".
                      Callers handling uploads should pass a sanitised name.

        Returns
        -------
        dict — the .pwcloud document, ready for `json.dumps`
        """
        if source_name is None:
            source_name = Path(source).name if isinstance(source, (str, Path)) else "unknown"

        # Stage 1: Preprocess
        log.info("[1/4] Preprocessing %s", source_name)
        preprocessor = Preprocessor(self.cfg.preprocess)
        pre_result = preprocessor.process(source)

        # Stage 2: Feature extraction
        log.info("[2/4] Extracting features (extractor=%s)", self.cfg.extractor)
        extractor = self._build_extractor()
        edge_map = extractor.extract(pre_result.image)
        sampling_map = self._build_sampling_map(pre_result.image, edge_map)

        # Stage 3: Point sampling
        log.info("[3/4] Sampling points (target=%d)", self.cfg.sampling.target_points)
        sampler = PointSampler(self.cfg.sampling)
        points = sampler.sample(sampling_map)

        # Stage 4: Serialise
        log.info("[4/4] Building document")
        exporter = PwcloudExporter(self.cfg.output)
        return exporter.build(
            points,
            source_image=source_name,
            source_size=pre_result.original_size,
            extractor=self.cfg.extractor,
        )

    def run(
        self,
        source: str | Path | np.ndarray | Image.Image,
        output_path: str | Path,
        *,
        debug: bool = False,
        debug_out: str | Path | None = None,
    ) -> Path:
        """
        Run the full pipeline and save the .pwcloud file.

        Parameters
        ----------
        source      : input image (path, ndarray, or PIL Image)
        output_path : destination .pwcloud path
        debug       : if True, save a debug overlay image
        debug_out   : path for the debug image (default: <output>.debug.png)

        Returns
        -------
        Path — resolved output path
        """
        source_name = Path(source).name if isinstance(source, (str, Path)) else "unknown"

        # The debug overlay needs the intermediate edge map, which `build` does
        # not surface. Recomputing the first two stages here keeps `build` lean
        # for the common case; debug is a development path, not a hot one.
        if debug:
            preprocessor = Preprocessor(self.cfg.preprocess)
            pre_result = preprocessor.process(source)
            edge_map = self._build_extractor().extract(pre_result.image)
            self._save_debug(
                pre_result.image,
                edge_map,
                str(debug_out or f"{output_path}.debug.png"),
            )

        data = self.build(source, source_name=source_name)
        return PwcloudExporter(self.cfg.output).write(data, output_path)

    @staticmethod
    def register_extractor(name: str, factory: Callable[..., Any]) -> None:
        """Register a custom extractor (module-level convenience wrapper)."""
        register_extractor(name, factory)

    # ── Private ───────────────────────────────────────────────────────────────

    def _build_extractor(self) -> Any:
        name = self.cfg.extractor

        # User-registered custom extractor takes priority
        if name in _EXTRACTOR_REGISTRY:
            log.debug("Using registered extractor: %s", name)
            return _EXTRACTOR_REGISTRY[name]()

        if name == "classic":
            return CannyExtractor(self.cfg.extractor_classic)
        if name == "ml":
            return MLExtractor(self.cfg.extractor_ml)

        raise ValueError(
            f"Unknown extractor '{name}'. "
            f"Valid built-ins: 'classic', 'ml'. "
            f"Registered: {list(_EXTRACTOR_REGISTRY)}"
        )

    def _build_sampling_map(self, image: np.ndarray, edge_map: EdgeMap) -> EdgeMap:
        """Combine edges and tonal local contrast into a more image-faithful importance map."""
        mode = self.cfg.sampling.feature_mode
        if mode == "edge":
            return edge_map

        if mode == "bw_intensity":
            from scipy.ndimage import gaussian_filter  # type: ignore[import-not-found]

            intensity = image.astype(np.float32)
            if self.cfg.sampling.bw_blur_sigma > 0:
                intensity = gaussian_filter(intensity, sigma=self.cfg.sampling.bw_blur_sigma)

            polarity = self.cfg.sampling.bw_polarity
            if polarity == "white_more":
                importance = intensity
            elif polarity == "black_more":
                importance = 1.0 - intensity
            else:
                raise ValueError(
                    f"Unknown bw_polarity '{polarity}'. Valid: 'white_more', 'black_more'"
                )

            importance = np.power(importance.clip(0, 1), self.cfg.sampling.bw_gamma)
            imp_max = float(importance.max())
            if imp_max > 0:
                importance = importance / imp_max

            positive = importance[importance > 0]
            quantile_threshold = (
                float(np.quantile(positive, self.cfg.sampling.feature_quantile))
                if positive.size > 0
                else 0.0
            )
            threshold = max(self.cfg.sampling.feature_floor, quantile_threshold)
            binary = importance >= threshold
            return EdgeMap(binary=binary, magnitude=importance.astype(np.float32))

        from scipy.ndimage import gaussian_filter  # type: ignore[import-not-found]

        smooth = gaussian_filter(image, sigma=self.cfg.sampling.tone_sigma)
        tone_map = np.abs(image - smooth).astype(np.float32)

        tone_max = float(tone_map.max())
        if tone_max > 0:
            tone_map /= tone_max
        tone_map = np.power(tone_map.clip(0, 1), self.cfg.sampling.tone_gamma)

        if mode == "tone":
            importance = tone_map
        else:
            importance = (
                self.cfg.sampling.edge_weight * edge_map.magnitude
                + self.cfg.sampling.tone_weight * tone_map
            )

        importance = importance.astype(np.float32)
        imp_max = float(importance.max())
        if imp_max > 0:
            importance /= imp_max

        positive = importance[importance > 0]
        quantile_threshold = (
            float(np.quantile(positive, self.cfg.sampling.feature_quantile))
            if positive.size > 0
            else 0.0
        )
        threshold = max(self.cfg.sampling.feature_floor, quantile_threshold)
        binary = importance >= threshold

        return EdgeMap(binary=binary, magnitude=importance)

    @staticmethod
    def _save_debug(image: np.ndarray, edge_map: EdgeMap, out_path: str) -> None:
        """Save a side-by-side debug image: grayscale | edge binary | magnitude."""
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            log.warning("matplotlib not available; skipping debug image")
            return

        fig, axes = plt.subplots(1, 3, figsize=(15, 5))
        axes[0].imshow(image, cmap="gray", vmin=0, vmax=1)
        axes[0].set_title("Preprocessed (grayscale)")
        axes[1].imshow(edge_map.binary, cmap="gray")
        axes[1].set_title("Edge binary")
        axes[2].imshow(edge_map.magnitude, cmap="hot", vmin=0, vmax=1)
        axes[2].set_title("Edge magnitude")
        for ax in axes:
            ax.axis("off")
        plt.tight_layout()
        plt.savefig(out_path, dpi=150, bbox_inches="tight")
        plt.close(fig)
        log.info("Debug image saved → %s", out_path)
