"""
particle_wave.tool
──────────────────
Python toolchain for converting images to .pwcloud particle-wave point clouds.

Public API:
    Pipeline       — orchestrates all processing stages
    PipelineConfig — unified configuration dataclass (also loadable from YAML)

Quick usage:
    from particle_wave.tool import Pipeline
    Pipeline().run("logo.png", "logo.pwcloud")
"""

from .pipeline import Pipeline, PipelineConfig, register_extractor

__all__ = ["Pipeline", "PipelineConfig", "register_extractor"]
