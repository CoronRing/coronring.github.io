# pyright: reportMissingImports=false
# ruff: noqa: I001

"""
tests/test_pipeline.py
──────────────────────
Integration tests for the full image → .pwcloud pipeline.
All tests run without heavy dependencies (cv2, onnxruntime) by using
synthetically generated images and the pure-scipy fallback paths.
"""

from __future__ import annotations

import json

import numpy as np
import pytest
from PIL import Image

from particle_wave.tool.exporters.pwcloud import ExportConfig, PwcloudExporter
from particle_wave.tool.pipeline import Pipeline, PipelineConfig
from particle_wave.tool.stages.extract_edges import CannyConfig, CannyExtractor
from particle_wave.tool.stages.preprocess import PreprocessConfig, Preprocessor
from particle_wave.tool.stages.sample_points import PointSampler, SamplingConfig


# ──────────────────────────────────────────────────────────────────────────────
# Fixtures
# ──────────────────────────────────────────────────────────────────────────────

def _make_test_image(w: int = 64, h: int = 64) -> np.ndarray:
    """Create a simple synthetic test image (white rectangle on black)."""
    img = np.zeros((h, w, 3), dtype=np.uint8)
    img[16:48, 16:48] = 255
    return img


@pytest.fixture
def test_image_ndarray():
    return _make_test_image()


@pytest.fixture
def test_image_pil():
    return Image.fromarray(_make_test_image())


@pytest.fixture
def test_image_file(tmp_path):
    p = tmp_path / "test.png"
    Image.fromarray(_make_test_image()).save(str(p))
    return p


# ──────────────────────────────────────────────────────────────────────────────
# Unit tests — Preprocessor
# ──────────────────────────────────────────────────────────────────────────────

class TestPreprocessor:
    def test_output_shape_and_dtype(self, test_image_ndarray):
        result = Preprocessor().process(test_image_ndarray)
        assert result.image.dtype == np.float32
        assert result.image.ndim == 2

    def test_output_range(self, test_image_ndarray):
        result = Preprocessor().process(test_image_ndarray)
        assert result.image.min() >= 0.0
        assert result.image.max() <= 1.0

    def test_resize_respects_max_resolution(self):
        large = np.zeros((2000, 3000, 3), dtype=np.uint8)
        cfg = PreprocessConfig(max_resolution=512)
        result = Preprocessor(cfg).process(large)
        height, width = result.image.shape
        assert max(height, width) <= 512

    def test_accepts_pil_image(self, test_image_pil):
        result = Preprocessor().process(test_image_pil)
        assert result.image.ndim == 2

    def test_accepts_path(self, test_image_file):
        result = Preprocessor().process(test_image_file)
        assert result.image.ndim == 2

    def test_original_size_preserved(self):
        img = np.zeros((100, 200, 3), dtype=np.uint8)
        result = Preprocessor().process(img)
        assert result.original_size == (200, 100)  # (W, H)


# ──────────────────────────────────────────────────────────────────────────────
# Unit tests — CannyExtractor
# ──────────────────────────────────────────────────────────────────────────────

class TestCannyExtractor:
    def test_binary_is_bool(self, test_image_ndarray):
        pre = Preprocessor().process(test_image_ndarray)
        edge = CannyExtractor().extract(pre.image)
        assert edge.binary.dtype == bool

    def test_magnitude_range(self, test_image_ndarray):
        pre = Preprocessor().process(test_image_ndarray)
        edge = CannyExtractor().extract(pre.image)
        assert edge.magnitude.min() >= 0.0
        assert edge.magnitude.max() <= 1.0

    def test_detects_edges(self):
        """A white rectangle on black should produce edge pixels."""
        img = np.zeros((64, 64, 3), dtype=np.uint8)
        img[10:54, 10:54] = 255
        pre = Preprocessor().process(img)
        edge = CannyExtractor(
            CannyConfig(blur_sigma=1.0, low_thresh=0.02, high_thresh=0.06)
        ).extract(pre.image)
        assert edge.binary.sum() > 0

    def test_blank_image_no_edges(self):
        img = np.full((64, 64, 3), 128, dtype=np.uint8)
        pre = Preprocessor().process(img)
        edge = CannyExtractor().extract(pre.image)
        assert edge.binary.sum() == 0


# ──────────────────────────────────────────────────────────────────────────────
# Unit tests — PointSampler
# ──────────────────────────────────────────────────────────────────────────────

class TestPointSampler:
    def _get_edge_map(self, ndarray):
        pre = Preprocessor().process(ndarray)
        return CannyExtractor(
            CannyConfig(blur_sigma=1.0, low_thresh=0.02, high_thresh=0.06)
        ).extract(pre.image)

    def test_output_count_nonzero(self, test_image_ndarray):
        edge = self._get_edge_map(test_image_ndarray)
        pts = PointSampler(SamplingConfig(target_points=50, rng_seed=42)).sample(edge)
        assert pts.N > 0

    def test_coordinates_in_unit_square(self, test_image_ndarray):
        edge = self._get_edge_map(test_image_ndarray)
        pts = PointSampler(SamplingConfig(target_points=100, rng_seed=0)).sample(edge)
        assert pts.x.min() >= 0.0 and pts.x.max() <= 1.0
        assert pts.y.min() >= 0.0 and pts.y.max() <= 1.0

    def test_weight_in_unit_range(self, test_image_ndarray):
        edge = self._get_edge_map(test_image_ndarray)
        pts = PointSampler(SamplingConfig(target_points=50, rng_seed=1)).sample(edge)
        assert pts.weight.min() >= 0.0
        assert pts.weight.max() <= 1.0

    def test_reproducible_with_seed(self, test_image_ndarray):
        edge = self._get_edge_map(test_image_ndarray)
        pts1 = PointSampler(SamplingConfig(target_points=50, rng_seed=99)).sample(edge)
        pts2 = PointSampler(SamplingConfig(target_points=50, rng_seed=99)).sample(edge)
        np.testing.assert_array_equal(pts1.x, pts2.x)

    def test_background_fill(self, test_image_ndarray):
        edge = self._get_edge_map(test_image_ndarray)
        without = PointSampler(
            SamplingConfig(target_points=50, fill_background=False, rng_seed=5)
        ).sample(edge)
        with_bg = PointSampler(
            SamplingConfig(
                target_points=50,
                fill_background=True,
                background_ratio=0.5,
                rng_seed=5,
            )
        ).sample(edge)
        # Background fill should increase total count
        assert with_bg.N >= without.N


# ──────────────────────────────────────────────────────────────────────────────
# Unit tests — PwcloudExporter
# ──────────────────────────────────────────────────────────────────────────────

class TestPwcloudExporter:
    def _make_points(self, n: int = 10):
        from particle_wave.tool.stages.sample_points import SampledPoints
        rng = np.random.default_rng(0)
        return SampledPoints(
            x=rng.random(n).astype(np.float32),
            y=rng.random(n).astype(np.float32),
            weight=rng.random(n).astype(np.float32),
            group=np.zeros(n, dtype=np.int32),
            N=n,
        )

    def test_flat_encoding_structure(self):
        pts  = self._make_points(5)
        exp  = PwcloudExporter(ExportConfig(encoding="flat"))
        doc  = exp.build(pts)
        assert doc["encoding"] == "flat"
        assert "data" in doc
        assert len(doc["data"]) == 5 * doc["stride"]

    def test_object_encoding_structure(self):
        pts  = self._make_points(5)
        exp  = PwcloudExporter(ExportConfig(encoding="object"))
        doc  = exp.build(pts)
        assert doc["encoding"] == "object"
        assert len(doc["points"]) == 5

    def test_save_and_inspect(self, tmp_path):
        pts = self._make_points(20)
        exp = PwcloudExporter(ExportConfig(encoding="flat"))
        out = exp.save(
            pts,
            tmp_path / "test.pwcloud",
            source_image="test.png",
            source_size=(64, 64),
        )
        assert out.exists()
        with out.open() as fh:
            doc = json.load(fh)
        assert doc["version"] == "1.0.0"
        assert doc["meta"]["point_count"] == 20

    def test_inspect_output_contains_expected_fields(self, tmp_path):
        pts = self._make_points(30)
        exp = PwcloudExporter()
        out = exp.save(pts, tmp_path / "inspect_test.pwcloud")
        summary = PwcloudExporter.inspect(out)
        assert "Points:" in summary
        assert "Weight distribution:" in summary
        assert "Bounding box" in summary


# ──────────────────────────────────────────────────────────────────────────────
# Integration test — full pipeline
# ──────────────────────────────────────────────────────────────────────────────

class TestPipeline:
    def test_end_to_end_from_ndarray(self, tmp_path, test_image_ndarray):
        cfg            = PipelineConfig()
        cfg.sampling.target_points = 50
        cfg.sampling.rng_seed = 42
        cfg.extractor_classic.blur_sigma = 1.0
        cfg.extractor_classic.low_thresh = 0.02
        cfg.extractor_classic.high_thresh = 0.06

        out = Pipeline(cfg).run(test_image_ndarray, tmp_path / "out.pwcloud")

        assert out.exists()
        with out.open() as fh:
            doc = json.load(fh)
        assert doc["version"] == "1.0.0"
        assert doc["meta"]["point_count"] > 0

    def test_end_to_end_from_file(self, tmp_path, test_image_file):
        cfg            = PipelineConfig()
        cfg.sampling.target_points = 30
        cfg.sampling.rng_seed = 0
        out = Pipeline(cfg).run(test_image_file, tmp_path / "from_file.pwcloud")
        assert out.exists()


# ──────────────────────────────────────────────────────────────────────────────
# Config tests
# ──────────────────────────────────────────────────────────────────────────────

class TestPipelineConfig:
    def test_from_defaults(self):
        cfg = PipelineConfig.from_defaults()
        assert cfg.extractor == "classic"
        assert cfg.sampling.target_points == 4000

    def test_from_dict_override(self):
        cfg = PipelineConfig.from_dict({
            "extractor": "ml",
            "sampling": {"target_points": 1000},
        })
        assert cfg.extractor == "ml"
        assert cfg.sampling.target_points == 1000
