"""
pwcloud.py
──────────
Serialises a SampledPoints result to the .pwcloud JSON format (v1.0.0).

Supports two encodings:
    - "object"  → array of {x, y, w, g} dicts (human-readable)
    - "flat"    → single data array with stride metadata (40% smaller)
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

import numpy as np

from ..stages.sample_points import SampledPoints  # type: ignore

log = logging.getLogger(__name__)

# The *format* version, which is independent of the package version: the
# schema below is a contract with every consumer that has ever read a
# .pwcloud, so it moves only when the layout does.
PWCLOUD_VERSION = "1.0.0"
PWCLOUD_SCHEMA  = f"https://sensering.dev/schemas/pwcloud/{PWCLOUD_VERSION}"


def _package_version() -> str:
    """The installed package version, for the `generator` provenance string."""
    try:
        from importlib.metadata import version

        return version("particle-wave-tool")
    except Exception:  # noqa: BLE001 - provenance must never break an export
        return "unknown"


# Read once: this is provenance metadata, not something that changes per call.
# Previously spelled out as a literal in two default arguments, which meant a
# release could and did leave it reporting the version before last.
DEFAULT_GENERATOR = f"particle_wave_tool/{_package_version()}"


# ──────────────────────────────────────────────────────────────────────────────
# Config
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class ExportConfig:
    encoding: Literal["object", "flat"] = "flat"
    """
    'flat'   — compact single-array encoding (preferred for production).
    'object' — human-readable points array (better for debugging).
    """

    pretty: bool = False
    """Pretty-print the JSON output. Increases file size significantly."""

    float_precision: int = 4
    """Number of decimal places for x/y/w coordinates."""


# ──────────────────────────────────────────────────────────────────────────────
# Exporter
# ──────────────────────────────────────────────────────────────────────────────

class PwcloudExporter:
    def __init__(self, config: ExportConfig | None = None) -> None:
        self.cfg = config or ExportConfig()

    # ── Public ────────────────────────────────────────────────────────────────

    def build(
        self,
        points: SampledPoints,
        source_image: str = "",
        source_size: tuple[int, int] | None = None,
        extractor: str = "unknown",
        generator: str = DEFAULT_GENERATOR,
    ) -> dict:
        """
        Construct the .pwcloud payload as a Python dict.

        Parameters
        ----------
        points       : SampledPoints from the sampling stage
        source_image : original file name or identifier
        source_size  : (W, H) of the original image before preprocessing
        extractor    : name of the extraction backend used
        generator    : tool name/version string

        Returns
        -------
        dict  — ready to be serialised with json.dumps
        """
        meta = {
            "source_image": str(source_image),
            "source_size":  list(source_size) if source_size else None,
            "extractor":    extractor,
            "point_count":  points.N,
            "generated_at": datetime.now(tz=timezone.utc).isoformat().replace("+00:00", "Z"),
            "generator":    generator,
        }

        if self.cfg.encoding == "flat":
            payload = self._flat_encoding(points)
        else:
            payload = self._object_encoding(points)

        return {"$schema": PWCLOUD_SCHEMA, "version": PWCLOUD_VERSION, "meta": meta, **payload}

    def save(
        self,
        points: SampledPoints,
        output_path: str | Path,
        *,
        source_image: str = "",
        source_size: tuple[int, int] | None = None,
        extractor: str = "unknown",
        generator: str = DEFAULT_GENERATOR,
    ) -> Path:
        """
        Build and write the .pwcloud file to disk.

        Returns
        -------
        Path  — resolved output path
        """
        data = self.build(
            points,
            source_image=source_image,
            source_size=source_size,
            extractor=extractor,
            generator=generator,
        )
        return self.write(data, output_path)

    def write(self, data: dict, output_path: str | Path) -> Path:
        """
        Write an already-built .pwcloud document to disk.

        Split out from `save` so a caller that produced the document some other
        way — `Pipeline.build`, a cached result, a hand-assembled cloud — can
        persist it without re-running the sampler, and so there is exactly one
        place that decides how the JSON is formatted.

        Returns
        -------
        Path  — resolved output path
        """
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)

        indent = 2 if self.cfg.pretty else None
        separators = None if self.cfg.pretty else (",", ":")

        with path.open("w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=indent, separators=separators, allow_nan=False)

        size_kb = path.stat().st_size / 1024
        log.info("Saved %s (%.1f KB, %d points)", path, size_kb, data["meta"]["point_count"])
        return path

    # ── Private ───────────────────────────────────────────────────────────────

    def _flat_encoding(self, points: SampledPoints) -> dict:
        """Interleave [x0, y0, w0, g0,  x1, y1, w1, g1, ...]."""
        p = self.cfg.float_precision
        n = points.N
        data: list[float | int] = []
        for i in range(n):
            data.append(round(float(points.x[i]), p))
            data.append(round(float(points.y[i]), p))
            data.append(round(float(points.weight[i]), p))
            data.append(int(points.group[i]))
        return {
            "encoding": "flat",
            "stride":   4,
            "fields":  ["x", "y", "w", "g"],
            "data":     data,
        }

    def _object_encoding(self, points: SampledPoints) -> dict:
        """Array of {x, y, w, g} objects."""
        p = self.cfg.float_precision
        pts = []
        for i in range(points.N):
            pts.append({
                "x": round(float(points.x[i]), p),
                "y": round(float(points.y[i]), p),
                "w": round(float(points.weight[i]), p),
                "g": int(points.group[i]),
            })
        return {"encoding": "object", "points": pts}

    # ── Inspect helper ────────────────────────────────────────────────────────

    @staticmethod
    def inspect(path: str | Path) -> str:
        """
        Return a human-readable summary of a .pwcloud file.
        Equivalent to `particle-wave inspect` CLI output.
        """
        path = Path(path)
        with path.open("r", encoding="utf-8") as fh:
            doc = json.load(fh)

        meta  = doc.get("meta", {})
        enc   = doc.get("encoding", "object")

        if enc == "flat":
            data   = doc.get("data", [])
            stride = doc.get("stride", 4)
            fields = doc.get("fields", ["x", "y", "w", "g"])
            point_count = len(data) // stride
            xi = fields.index("x") if "x" in fields else 0
            yi = fields.index("y") if "y" in fields else 1
            wi = fields.index("w") if "w" in fields else 2
            xs = np.array(data[xi::stride], dtype=np.float32)
            ys = np.array(data[yi::stride], dtype=np.float32)
            ws = np.array(data[wi::stride], dtype=np.float32)
        else:
            pts = doc.get("points", [])
            point_count = len(pts)
            xs  = np.array([p["x"] for p in pts], dtype=np.float32)
            ys  = np.array([p["y"] for p in pts], dtype=np.float32)
            ws  = np.array([p.get("w", 1.0) for p in pts], dtype=np.float32)

        size_kb = path.stat().st_size / 1024
        src_size = meta.get("source_size")
        src_size_str = f"{src_size[0]} × {src_size[1]}" if src_size else "unknown"

        lines = [
            f"File:          {path.name}",
            f"Version:       {doc.get('version', '?')}",
            f"Points:        {point_count}",
            f"Source size:   {src_size_str}",
            f"Extractor:     {meta.get('extractor', 'unknown')}",
            f"Generated:     {meta.get('generated_at', 'unknown')}",
            f"Encoding:      {enc}",
            f"File size:     {size_kb:.1f} KB",
            "",
            "Weight distribution:",
            f"  min:   {ws.min():.2f}   max:  {ws.max():.2f}   "
            f"mean:  {ws.mean():.2f}   std:  {ws.std():.2f}",
            "",
            "Bounding box (normalised):",
            f"  x: [{xs.min():.2f}, {xs.max():.2f}]   "
            f"y: [{ys.min():.2f}, {ys.max():.2f}]",
        ]
        return "\n".join(lines)
