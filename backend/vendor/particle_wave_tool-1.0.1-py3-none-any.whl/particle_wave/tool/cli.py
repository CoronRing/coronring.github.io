"""
cli.py
──────
Typer-based CLI for the particle_wave conversion tool.

Commands:
    convert   — Convert an image to a .pwcloud point cloud
    inspect   — Print a summary of an existing .pwcloud file

Usage:
    particle-wave convert input.png -o output.pwcloud
    particle-wave convert input.png --extractor ml --target-points 5000
    particle-wave inspect output.pwcloud
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path

try:
    import typer
except ImportError:
    print(
        "[particle-wave] 'typer' is required for the CLI. "
        "Install with: pip install 'typer[all]'",
        file=sys.stderr,
    )
    raise

from .exporters.pwcloud import PwcloudExporter  # type: ignore
from .pipeline import Pipeline, PipelineConfig  # type: ignore

# ──────────────────────────────────────────────────────────────────────────────
app = typer.Typer(
    name="particle-wave",
    help="Convert images to interactive particle-wave point clouds (.pwcloud).",
    no_args_is_help=True,
    pretty_exceptions_show_locals=False,
)


def _setup_logging(verbose: bool) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        format="%(levelname)-8s %(message)s",
        level=level,
        stream=sys.stderr,
    )


# ──────────────────────────────────────────────────────────────────────────────
# convert
# ──────────────────────────────────────────────────────────────────────────────

@app.command("convert")
def cmd_convert(
    input_image: Path = typer.Argument(..., help="Input image file (PNG, JPEG, WebP, etc.)"),

    # Output
    output: Path | None = typer.Option(
        None, "--output", "-o",
        help="Output .pwcloud path. Defaults to <input>.pwcloud in the same directory.",
    ),

    # Config file override
    config_file: Path | None = typer.Option(
        None, "--config", "-c",
        help="Path to a YAML config file. CLI flags override file values.",
    ),

    # Extractor
    extractor: str = typer.Option("classic", help="'classic' (Canny) or 'ml' (DexiNed/HED)."),
    ml_model: str  = typer.Option("dexined", help="ML model: 'dexined' | 'hed'."),
    ml_threshold: float = typer.Option(0.4, help="ML edge probability threshold [0,1]."),

    # Preprocessing
    max_resolution: int   = typer.Option(1024, help="Longest edge cap (pixels)."),
    clahe_clip: float     = typer.Option(2.0,  help="CLAHE clip limit (0 = off)."),
    blur_sigma: float     = typer.Option(1.4,  help="Gaussian pre-blur sigma."),
    canny_low: float      = typer.Option(0.05, help="Canny low threshold [0,1]."),
    canny_high: float     = typer.Option(0.15, help="Canny high threshold [0,1]."),

    # Sampling
    target_points: int    = typer.Option(4000, help="Desired number of output points."),
    min_radius: float     = typer.Option(2.0,  help="Min inter-point distance (px)."),
    max_radius: float     = typer.Option(12.0, help="Max inter-point distance (px)."),
    radius_gamma: float   = typer.Option(0.5,  help="Density curve exponent."),
    fill_background: bool = typer.Option(False, help="Add sparse background points."),
    background_ratio: float = typer.Option(0.15, help="Background/edge point ratio."),
    rng_seed: int | None = typer.Option(None, help="RNG seed for reproducibility."),
    feature_mode: str = typer.Option(
        "hybrid",
        help="Sampling feature mode: 'edge' | 'hybrid' | 'bw_intensity'.",
    ),
    bw_polarity: str = typer.Option(
        "white_more",
        help="BW mode polarity: 'white_more' | 'black_more'.",
    ),
    bw_gamma: float = typer.Option(1.0, help="Gamma on BW importance map (>0)."),
    bw_blur_sigma: float = typer.Option(0.0, help="Optional Gaussian blur sigma for BW map."),

    # Output format
    encoding: str         = typer.Option("flat",  help="'flat' (compact) or 'object' (readable)."),
    pretty: bool          = typer.Option(False,  help="Pretty-print JSON output."),
    float_precision: int  = typer.Option(4,      help="Decimal places for coordinates."),

    # Debug
    debug: bool           = typer.Option(False, help="Save a debug overlay image."),
    debug_out: Path | None = typer.Option(None, help="Debug image path."),
    verbose: bool         = typer.Option(False, "--verbose", "-v", help="Enable debug logging."),
) -> None:
    """Convert an image to a .pwcloud particle-wave point cloud."""

    _setup_logging(verbose)

    # Resolve output path
    out_path = output or input_image.with_suffix(".pwcloud")

    # Start from YAML config if provided, then apply CLI overrides
    if config_file:
        cfg = PipelineConfig.from_yaml(config_file)
    else:
        cfg = PipelineConfig.from_defaults()

    # Apply CLI overrides
    cfg.extractor = extractor

    cfg.preprocess.max_resolution = max_resolution
    cfg.preprocess.clahe_clip     = clahe_clip
    cfg.preprocess.blur_sigma     = 0.0  # preprocess blur separate from Canny blur

    cfg.extractor_classic.blur_sigma  = blur_sigma
    cfg.extractor_classic.low_thresh  = canny_low
    cfg.extractor_classic.high_thresh = canny_high

    cfg.extractor_ml.model_name  = ml_model
    cfg.extractor_ml.threshold   = ml_threshold

    cfg.sampling.target_points    = target_points
    cfg.sampling.min_radius       = min_radius
    cfg.sampling.max_radius       = max_radius
    cfg.sampling.radius_gamma     = radius_gamma
    cfg.sampling.fill_background  = fill_background
    cfg.sampling.background_ratio = background_ratio
    cfg.sampling.rng_seed         = rng_seed
    cfg.sampling.feature_mode     = feature_mode
    cfg.sampling.bw_polarity      = bw_polarity
    cfg.sampling.bw_gamma         = bw_gamma
    cfg.sampling.bw_blur_sigma    = bw_blur_sigma

    cfg.output.encoding        = encoding
    cfg.output.pretty          = pretty
    cfg.output.float_precision = float_precision

    pipeline = Pipeline(cfg)
    result = pipeline.run(
        input_image,
        out_path,
        debug=debug,
        debug_out=debug_out,
    )

    typer.echo(f"✓ {result}  ({result.stat().st_size // 1024} KB)", err=False)


# ──────────────────────────────────────────────────────────────────────────────
# inspect
# ──────────────────────────────────────────────────────────────────────────────

@app.command("inspect")
def cmd_inspect(
    pwcloud_file: Path = typer.Argument(..., help="Path to the .pwcloud file to inspect."),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Print a summary of a .pwcloud point cloud file."""
    _setup_logging(verbose)
    summary = PwcloudExporter.inspect(pwcloud_file)
    typer.echo(summary)


# ──────────────────────────────────────────────────────────────────────────────
# Entry point
# ──────────────────────────────────────────────────────────────────────────────

def main() -> None:
    app()


if __name__ == "__main__":
    main()
