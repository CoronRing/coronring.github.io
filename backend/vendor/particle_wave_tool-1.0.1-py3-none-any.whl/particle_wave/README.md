# Particle Wave

Convert any image into an interactive, physics-driven particle cloud that reacts to mouse hover, attraction, and ripple waves from clicks — embeddable on any webpage as a native ES module.

---

## Structure

```
src/particle_wave/
├── FE/                  # Browser module (ES module, zero runtime dependencies)
│   ├── particle-wave.js # Public API entry point
│   ├── core/            # Loader, ParticleSystem, PhysicsEngine, WaveManager, Renderer
│   ├── interaction/     # Mouse/touch → force/wave translation
│   ├── style/           # CSS
│   ├── utils/           # Math helpers, object pool
│   └── index.html       # Interactive demo with live controls
│
└── tool/                # Python toolchain  (image → .pwcloud)
    ├── cli.py           # `particle-wave convert / inspect`
    ├── pipeline.py      # Stage orchestrator
    ├── stages/          # preprocess · extract_edges · extract_ml · sample_points
    ├── exporters/       # pwcloud.py  (.pwcloud JSON serialiser)
    ├── config/          # defaults.yaml
    └── tests/           # pytest test suite
```

---

## Quick Start

### 1. Convert an image (Python tool)

```bash
# Install
cd src/particle_wave/tool
pip install -e "."            # core (scipy+Pillow Canny)
pip install -e ".[cv2]"       # + faster OpenCV Canny (recommended)
pip install -e ".[ml,debug]"  # + ML edge detection + matplotlib debug

# Convert
particle-wave convert logo.png -o logo.pwcloud

# With options
particle-wave convert photo.jpg \
  --extractor ml \
  --target-points 6000 \
  --fill-background \
  --encoding flat \
  -o photo.pwcloud

# Inspect
particle-wave inspect logo.pwcloud
```

### 2. Use in a webpage (ES module)

```html
<canvas id="pw" style="width:600px;height:400px"></canvas>
<link rel="stylesheet" href="/FE/style/particle-wave.css" />
<script type="module">
  import ParticleWave from '/FE/particle-wave.js';

  const pw = await ParticleWave.init(
    document.getElementById('pw'),
    {
      src:           '/assets/logo.pwcloud',
      mouseMode:    'repel',
      particleColor: '#7b93ff',
      rippleCount:   2,
    }
  );

  // Runtime API
  pw.setMode('attract');
  pw.triggerWave({ x: 300, y: 200 });
  pw.setConfig({ waveStrength: 200 });
  pw.pause();
  pw.resume();
  pw.destroy();
</script>
```

Open `FE/index.html` locally (via a dev server) for a live demo with interactive sliders.

---

## Configuration Reference

Full schemas are in the [System Design document](../../docs/particle_wave_design.md).

### Key JavaScript options

| Option | Default | Description |
|--------|---------|-------------|
| `src` | — | URL or object — the `.pwcloud` point cloud |
| `mouseMode` | `"repel"` | `"repel"` \| `"attract"` \| `"orbit"` \| `"none"` |
| `mouseStrength` | `60` | Peak attraction/repulsion force (px/s²) |
| `interactionRadius` | `120` | Mouse influence radius (px) |
| `waveStrength` | `120` | Click wave impulse amplitude (px/s²) |
| `waveSpeed` | `350` | Wave front propagation speed (px/s) |
| `waveDecay` | `1.8` | Amplitude decay rate (s⁻¹) |
| `rippleCount` | `2` | Concentric trailing ripples (0 = off) |
| `springK` | `0.08` | Spring stiffness (Hooke's Law) |
| `damping` | `0.12` | Velocity damping rate (s⁻¹) |
| `particleColor` | `"#ffffff"` | CSS hex or `(weight) => cssString` |
| `particleSize` | `2.0` | Base particle radius (px) |

### Key CLI options

```
particle-wave convert INPUT [OPTIONS]

  --extractor        classic|ml            (default: classic)
  --target-points    int                   (default: 4000)
  --min-radius       float px              (default: 2.0)
  --max-radius       float px              (default: 12.0)
  --fill-background                        (flag)
  --encoding         flat|object           (default: flat)
  --debug                                  (saves overlay image)
  --config           path/to/config.yaml
```

---

## Extending the System

### Custom extractor (Python)

```python
from particle_wave.tool import Pipeline, register_extractor
from particle_wave.tool.stages.extract_edges import EdgeMap
import numpy as np

class MyExtractor:
    def extract(self, image: np.ndarray) -> EdgeMap:
        # ... your logic ...
        return EdgeMap(binary=..., magnitude=...)

register_extractor("my_extractor", MyExtractor)

Pipeline().run("image.png", "out.pwcloud")  # set extractor="my_extractor" in config
```

### Custom force (JavaScript)

```js
class WindForce {
  apply(ps, dt) {
    const wind = 8;
    for (let i = 0; i < ps.N; i++) {
      ps.fx[i] += wind;
    }
  }
}
const pw = await ParticleWave.init(canvas, { src: '...' });
pw.addForce(new WindForce());
```

### Custom renderer (JavaScript)

```js
class MyRenderer {
  constructor(canvas, config) { /* ... */ }
  draw(ps, wm)  { /* paint particles from ps.px, ps.py, ps.sz */ }
  resize(w, h)  { /* handle resize */ }
  updateConfig(partial) { /* ... */ }
  destroy()     { /* cleanup */ }
}
ParticleWave.init(canvas, { src: '...', renderer: MyRenderer });
```

---

## Running Tests

```bash
cd src/particle_wave/tool
pip install -e ".[dev]"
pytest
```

---

## .pwcloud Format

See the [System Design](../../docs/particle_wave_design.md#10-data-format-specification) for the full schema. A minimal file:

```json
{
  "$schema": "https://sensering.dev/schemas/pwcloud/1.0.0",
  "version": "1.0.0",
  "meta": { "source_image": "logo.png", "source_size": [512, 512],
            "extractor": "classic", "point_count": 3200 },
  "encoding": "flat",
  "stride": 4,
  "fields": ["x", "y", "w", "g"],
  "data": [0.482, 0.315, 0.87, 0,  ...]
}
```
